## User-facing functions of the countfrontier package.
## A dataset is a frequency vector: freq[i] = number of observations equal to i - 1.

cf_default_families <- c("POIS", "PGD1", "PL", "PSh", "PAk", "PS", "PA", "NB", "ZIP")

cf_families <- function() {
  codes <- names(fam_all)
  data.frame(code = codes, name = unname(lab_all[codes]),
             parameters = vapply(codes, function(G) fam_all[[G]]$np, numeric(1)),
             row.names = NULL, stringsAsFactors = FALSE)
}

.check_freq <- function(freq) {
  if (!is.numeric(freq) || any(freq < 0) || any(freq != round(freq)) || sum(freq) < 2)
    stop("'freq' must be a vector of non-negative integer frequencies for the counts 0, 1, 2, ...")
  as.numeric(freq)
}
.check_fams <- function(families) {
  bad <- setdiff(families, names(fam_all))
  if (length(bad)) stop("unknown family code(s): ", paste(bad, collapse = ", "),
                        ". See cf_families().")
  families
}

cf_fit <- function(freq, families = cf_default_families) {
  freq <- .check_freq(freq); families <- .check_fams(families)
  fits <- fit_all(freq, families)
  ll <- vapply(fits, `[[`, numeric(1), "loglik")
  k <- vapply(families, function(G) fam_all[[G]]$np, numeric(1))
  aic <- -2 * ll + 2 * k
  out <- data.frame(family = families, name = unname(lab_all[families]), parameters = k,
                    logLik = ll, AIC = aic, dAIC = aic - min(aic), row.names = NULL)
  out[order(out$AIC), ]
}

cf_pmf <- function(family, mean, support = 0:400) {
  if (family == "PGD1") p <- exp(ldpgd(xs, theta_for_mean(mean, 1), 1))
  else if (family %in% names(gm_spec))
    p <- exp(ldgm(gm_spec[[family]], xs, exp(gm_rate_for_mean(gm_spec[[family]], mean))))
  else if (family == "POIS") p <- dpois(xs, mean)
  else stop("cf_pmf needs a one-parameter family; ", family, " has more parameters")
  p <- p / sum(p)
  p[support + 1]
}

cf_frontier <- function(true, mean, rival, alpha = 0.05, power = 0.80) {
  .check_fams(c(true, rival))
  fr <- frontier_pmf(cf_pmf(true, mean), rival, alpha = alpha, beta = 1 - power)
  data.frame(true = true, rival = rival, mean = mean, KL = fr$KL,
             n_star = fr$n_star, floor = fr$n_floor, row.names = NULL)
}

cf_frontier_fitted <- function(freq, true, rival, alpha = 0.05, power = 0.80) {
  freq <- .check_freq(freq); .check_fams(c(true, rival))
  d <- tab_of(freq); fit <- project(d$w, true, d$x)
  p <- exp(fam_all[[true]]$lp(fit$par, xs)); p <- p / sum(p)
  fr <- frontier_pmf(p, rival, alpha = alpha, beta = 1 - power)
  data.frame(true = true, rival = rival, n = sum(freq), KL = fr$KL,
             n_star = fr$n_star, floor = fr$n_floor, row.names = NULL)
}

cf_lookup <- function(families = c("PGD1", "PL", "PSh", "PAk", "PS", "PA"),
                      rivals = c(families, "NB"), means = c(0.25, 0.5, 1, 2, 5),
                      alpha = 0.05, power = 0.80) {
  rows <- list()
  for (F in families) for (mu in means) for (G in setdiff(rivals, F))
    rows[[length(rows) + 1]] <- cf_frontier(F, mu, G, alpha, power)
  do.call(rbind, rows)
}

cf_npmle <- function(freq, tol = 1e-5) {
  fit <- npmle(.check_freq(freq), tol = tol)
  list(logLik = fit$loglik, support = data.frame(lambda = fit$lambda, weight = fit$weight),
       certificate = fit$bound)
}

cf_gap_test <- function(freq, family, B = 199, seed = 1) {
  freq <- .check_freq(freq); .check_fams(family)
  r <- gap_test(freq, family, B = B, seed = seed)
  data.frame(family = family, gap = r[["gap"]], p_value = r[["p"]], row.names = NULL)
}

cf_mcs <- function(freq, families = cf_default_families, B = 2000, level = 0.10, seed = 1) {
  freq <- .check_freq(freq); families <- .check_fams(families)
  m <- mcs(freq, families, B = B, alpha_mcs = level, seed = seed)
  data.frame(family = m$family, MCS_p = m$MCS_p, in_set = m$in_set, row.names = NULL)
}

cf_audit <- function(freq, families = cf_default_families, B_gap = 199, B_mcs = 2000,
                     alpha = 0.05, power = 0.80, seed = 1) {
  freq <- .check_freq(freq); families <- .check_fams(families)
  fit <- cf_fit(freq, families)
  gaps <- do.call(rbind, lapply(families, function(G) cf_gap_test(freq, G, B_gap, seed)))
  ms <- cf_mcs(freq, families, B_mcs, seed = seed)
  tab <- merge(merge(fit, gaps, by = "family"), ms, by = "family")
  tab <- tab[order(tab$AIC), ]
  one <- tab$family[fit$parameters[match(tab$family, fit$family)] == 1 & tab$family != "POIS"]
  front <- if (length(one) >= 2) cf_frontier_fitted(freq, one[1], one[2], alpha, power) else NULL
  structure(list(n = sum(freq), mean = sum((seq_along(freq) - 1) * freq) / sum(freq),
                 table = tab, supported_set = tab$family[tab$in_set],
                 frontier = front, npmle = cf_npmle(freq)), class = "cf_audit")
}

print.cf_audit <- function(x, ...) {
  cat(sprintf("Count-distribution audit: n = %d, mean = %.3f\n\n", x$n, x$mean))
  t <- x$table
  print(data.frame(family = t$family, logLik = round(t$logLik, 2), dAIC = round(t$dAIC, 2),
                   NPMLE_gap = round(t$gap, 2), gap_p = round(t$p_value, 3),
                   MCS_p = round(t$MCS_p, 3), supported = ifelse(t$in_set, "yes", "no")),
        row.names = FALSE)
  cat("\nSupported set:", paste(x$supported_set, collapse = ", "), "\n")
  if (!is.null(x$frontier)) with(x$frontier, cat(sprintf(
    "Best one-parameter family %s vs %s: n* = %s, floor = %s (observed n = %d)%s\n",
    true, rival, format(n_star, big.mark = ","), format(floor, big.mark = ","), x$n,
    if (x$n < floor) "  -> below the floor: no method can separate them" else "")))
  invisible(x)
}
